import java.util.Date;

public class SimpleDateFormat {
    public static void main(String[] args) {
        String pattern = "MM-dd-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Date date= simpleDateFormat.("");
        System.out.println(date);
    }

}
