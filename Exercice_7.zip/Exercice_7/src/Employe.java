import java.util.Scanner;

public class Employe extends Personne{
    public static int montant = 0;
    public final int MinSalaire = 5000;
    private double salaire;
    private String poste;

   public Employe() {
    }

    public Employe(double salaire, String poste) {
        this.salaire = salaire;
        this.poste = poste;
        montant++;
    }

    public double getSalaire() {
        return salaire;
    }

    public String getPoste() {
        return poste;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    @Override
    public String toString() {
        return "Employe{" +
                "MinSalaire=" + MinSalaire +
                ", salaire=" + salaire +
                ", poste='" + poste + '\'' +
                '}';
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }
    @Override
    public void saisiP(){

        Scanner scan = new Scanner(System.in);
        System.out.println("Donner le poste");
        poste = scan.nextLine();
        do {
            System.out.println("Donner le salaire");
            salaire = scan.nextInt();
        }while (salaire <= 0);
    }

    @Override
    public void affiche() {
        System.out.println("poste : " + poste);
        System.out.println("Salaire : " + salaire);
    }

}
