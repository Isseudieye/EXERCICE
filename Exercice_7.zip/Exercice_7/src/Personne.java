import java.util.Date;
import java.util.Scanner;

public class Personne {
    private String nom;
    private Date date_de_naissance;
    private double taille;

    public Personne() {
    }

    public Personne(String nom, Date date_de_naissance, double taille) {
        this.nom = nom;
        this.date_de_naissance = date_de_naissance;
        this.taille = taille;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getDate_de_naissance() {
        return date_de_naissance;
    }

    public void setDate_de_naissance(Date date_de_naissance) {
        this.date_de_naissance = date_de_naissance;
    }

    public double getTaille() {
        return taille;
    }

    public void setTaille(double taille) {
        this.taille = taille;
    }

    @Override
    public String toString() {
        return "Personne{" +
                "nom='" + nom + '\'' +
                ", date_de_naissance=" + date_de_naissance +
                ", taille=" + taille +
                '}';
    }
    public void saisiP(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Donner le nom");
        nom = scan.nextLine();
        System.out.println("Donner la taille");
        taille= scan.nextInt();
    }
    public void affiche() {
        System.out.println("Nom : " + nom.toUpperCase());
        System.out.println("taille : " + taille);
        System.out.println("date_de_naissance: " + date_de_naissance);
    }
}
