import java.util.Random;

public class Math {
    public static void main(String[] args) {
        Random rand =new Random();
        for (int iCount = 0; iCount<5000; iCount++){
            int randomNumber= rand.nextInt(1000);
            System.out.println("Random: " + randomNumber);
        }

    }


}
